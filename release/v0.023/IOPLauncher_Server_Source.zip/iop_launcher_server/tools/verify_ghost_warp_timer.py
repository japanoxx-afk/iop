"""Emulate the native Ghost Warp deadline gate; never modify game files."""
import argparse
from pathlib import Path
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'analysis_lib'))
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_EAX, UC_X86_REG_ECX, UC_X86_REG_ESP


def check(exe, delay, tick):
    uc = Uc(UC_ARCH_X86, UC_MODE_32)
    uc.mem_map(0x400000, 0x500000)
    uc.mem_write(0x400000, exe)
    event, stack, sentinel = 0x810000, 0x820000, 0x800000
    put = lambda addr, value: uc.mem_write(addr, struct.pack('<I', value))
    # Run original deadline arithmetic, changing only an in-memory immediate.
    assert exe[0x482D7:0x482DD] == bytes.fromhex('81c12c010000')
    put(0x6C946C, 1000)
    put(0x4482D9, delay)
    uc.reg_write(UC_X86_REG_EAX, event)
    uc.emu_start(0x4482D1, 0x4482E0, count=10)
    deadline = struct.unpack('<I', uc.mem_read(event + 12, 4))[0]
    assert deadline == 1000 + delay
    put(0x6C946C, tick)
    put(stack, sentinel)
    put(stack + 4, event)
    uc.reg_write(UC_X86_REG_ESP, stack)
    uc.reg_write(UC_X86_REG_ECX, 0x830000)
    completed = []

    def stop_at_completion(machine, address, size, data):
        if address == 0x466971:
            completed.append(True)
            machine.emu_stop()

    uc.hook_add(UC_HOOK_CODE, stop_at_completion)
    uc.emu_start(0x466950, sentinel, count=100)
    assert bool(completed) == (tick >= deadline)
    if not completed:
        assert uc.reg_read(UC_X86_REG_EAX) == 1
    assert struct.unpack('<I', uc.mem_read(event + 20, 4))[0] == tick + 1
    print(f'delay={delay}, tick={tick}, deadline={deadline}, release_branch={bool(completed)}: PASS')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('exe', type=Path)
    args = parser.parse_args()
    data = args.exe.read_bytes()
    for delay in (300, 450):
        for tick in (1000, 1000 + delay - 1, 1000 + delay, 1000 + delay + 1):
            check(data, delay, tick)
    print('Deadline arithmetic/gate only; completion side effects and gameplay are not emulated.')
