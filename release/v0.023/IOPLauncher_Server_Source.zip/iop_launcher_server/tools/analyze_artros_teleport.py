"""Read-only evidence extraction for the Artros building W command."""
import argparse
import json
from pathlib import Path
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from iop_hotkey_layout import TABLES
from iop_hotkeys import normalize_exe, button_records


def analyze(root):
    exe = normalize_exe((root / 'iop.exe').read_bytes())
    # Guard fixed addresses: these are observations for this executable layout.
    signatures = {
        'ui_dispatch': (0xAA71D, 'ff248530af4a00'),
        'coordinate_command': (0xA0B77, 'c74605c00b0000'),
        'simulation_dispatch': (0x35CFB, '2dbb0b0000746883e805'),
    }
    checks = {name: exe[off:off + len(bytes.fromhex(h))].hex() == h
              for name, (off, h) in signatures.items()}
    if not all(checks.values()):
        raise ValueError(f'Unsupported executable layout: {checks}')
    rows = [r for r in TABLES['W']['rows']
            if r[1] == 27 and (r[0] >> 16) & 255 == 0x40]
    labels = [label.rstrip(b'\0').decode('cp949', errors='replace')
              for _, label, _ in button_records((root / 'data' / 'Button.res').read_bytes())
              if b'Warp' in label]
    return {
        'read_only': True,
        'signature_checks': checks,
        'artros_building_W_contexts': [f'{r[0]:08x}' for r in rows],
        'ui_command': 27,
        'ui_handler': hex(struct.unpack_from('<I', exe, 0xAAF30 + 26 * 4)[0]),
        'warp_button_labels': labels,
        'coordinate_command_candidate': 3008,
        'coordinate_command_builder': '0x4A0A30',
        'simulation_receiver': '0x435D0B -> object virtual slot 0xD4',
        'limitations': [
            'The virtual object type branch needs runtime confirmation.',
            'Completion timer and distance limit are not identified.',
            'No game files modified; no gameplay validation performed.',
        ],
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('game_dir', type=Path)
    args = parser.parse_args()
    print(json.dumps(analyze(args.game_dir), ensure_ascii=False, indent=2))
